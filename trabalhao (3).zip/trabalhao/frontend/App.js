import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ProductList from './screens/ProductList';
import ProductForm from './screens/ProductForm';
import ProductDetails from './screens/ProductDetails';
import 'react-native-gesture-handler';


const Stack = createStackNavigator();

export default function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="ProductList">
                <Stack.Screen name="ProductList" component={ProductList} options={{ title: 'Produtos' }} />
                <Stack.Screen name="ProductForm" component={ProductForm} options={{ title: 'Novo Produto' }} />
                <Stack.Screen name="ProductDetails" component={ProductDetails} options={{ title: 'Detalhes' }} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}
