import React from 'react';
import { View, Text, StyleSheet, Button, Image, Alert } from 'react-native';
import axios from 'axios';

export default function ProductDetails({ route, navigation }) {
    const { product } = route.params;

    const handleDelete = async () => {
        try {
            await axios.delete(`http://192.168.100.44:8081/products/${product._id}`);
            Alert.alert('Sucesso', 'Produto deletado com sucesso!');
            navigation.goBack();
        } catch (error) {
            console.error('Erro ao deletar produto:', error);
            Alert.alert('Erro', 'Não foi possível deletar o produto.');
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.name}>{product.name}</Text>
            <Text style={styles.description}>{product.description}</Text>
            <Text style={styles.quantity}>Quantidade: {product.quantity}</Text>
            {product.photo && (
                <Image style={styles.image} source={{ uri: `http://192.168.100.44:8081/${product.photo}` }} />
            )}
            <Button title="Deletar" onPress={handleDelete} color="red" />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
    },
    name: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    description: {
        fontSize: 16,
        marginVertical: 8,
    },
    quantity: {
        fontSize: 16,
        color: '#555',
    },
    image: {
        width: '100%',
        height: 200,
        resizeMode: 'cover',
        marginVertical: 16,
    },
});
