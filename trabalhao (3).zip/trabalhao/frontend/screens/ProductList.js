import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Button, ActivityIndicator, Alert } from 'react-native';
import axios from 'axios';

export default function ProductList({ navigation }) {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            const response = await axios.get('http://192.168.100.44:8081/products');  // A URL do seu backend
            setProducts(response.data);  // Atualiza o estado com a lista de produtos
        } catch (error) {
            setError('Erro ao buscar produtos. Tente novamente mais tarde.');
            console.error('Erro ao buscar produtos:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleProductPress = (product) => {
        navigation.navigate('ProductDetails', { product });
    };

    if (loading) {
        return (
            <View style={styles.loaderContainer}>
                <ActivityIndicator size="large" color="#0000ff" />
            </View>
        );
    }

    if (error) {
        return (
            <View style={styles.errorContainer}>
                <Text>{error}</Text>
                <Button title="Tentar novamente" onPress={fetchProducts} />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <Button title="Adicionar Produto" onPress={() => navigation.navigate('ProductForm')} />
            <FlatList
                data={products}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        style={styles.productItem}
                        onPress={() => handleProductPress(item)}
                    >
                        <Text style={styles.productName}>{item.name}</Text>
                        <Text style={styles.productQuantity}>Quantidade: {item.quantity}</Text>
                    </TouchableOpacity>
                )}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
    },
    productItem: {
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
    },
    productName: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    productQuantity: {
        fontSize: 14,
        color: '#555',
    },
    loaderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    errorContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
