import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Alert } from 'react-native';
import axios from 'axios';

export default function ProductForm({ navigation }) {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [quantity, setQuantity] = useState('');

    const handleSave = async () => {
        if (!name || !description || !quantity) {
            Alert.alert('Erro', 'Por favor, preencha todos os campos.');
            return;
        }

        if (isNaN(quantity) || Number(quantity) <= 0) {
            Alert.alert('Erro', 'Quantidade deve ser um número válido maior que 0.');
            return;
        }

        try {
            await axios.post('http://192.168.100.44:8081/products', {
                name,
                description,
                quantity: Number(quantity),
            });
            Alert.alert('Sucesso', 'Produto criado com sucesso!');
            setName('');
            setDescription('');
            setQuantity('');
            navigation.goBack();
        } catch (error) {
            console.error('Erro ao criar produto:', error);
            Alert.alert('Erro', 'Não foi possível criar o produto.');
        }
    };

    return (
        <View style={styles.container}>
            <TextInput
                style={styles.input}
                placeholder="Nome"
                value={name}
                onChangeText={setName}
            />
            <TextInput
                style={styles.input}
                placeholder="Descrição"
                value={description}
                onChangeText={setDescription}
            />
            <TextInput
                style={styles.input}
                placeholder="Quantidade"
                value={quantity}
                onChangeText={setQuantity}
                keyboardType="numeric"
            />
            <Button title="Salvar" onPress={handleSave} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 8,
        padding: 8,
        marginBottom: 16,
    },
});
