// Importar dependências
const express = require('express');
const multer = require('multer');
const path = require('path');
const { Sequelize, DataTypes } = require('sequelize');
const cors = require('cors');

// Configuração do Sequelize para conectar ao PostgreSQL
const sequelize = new Sequelize('postgres://todo_dev_db:todo_dev_db@localhost:5432/todo_dev_db', {
    dialect: 'postgres',
    logging: false, // Desativa o log de consultas
});

// Testar a conexão com o PostgreSQL
sequelize.authenticate()
    .then(() => console.log('Conectado ao PostgreSQL!'))
    .catch(err => console.error('Erro de conexão ao PostgreSQL:', err));

// Definir o modelo de Produto utilizando Sequelize
const Product = sequelize.define('Product', {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    description: {
        type: DataTypes.STRING,
    },
    quantity: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    photo: {
        type: DataTypes.STRING,
    }
}, {
    tableName: 'products',
    timestamps: false, // Desativar timestamps automáticos
});

// Sincronizar com o banco de dados
sequelize.sync()
    .then(() => console.log('Modelo Product sincronizado com o banco.'))
    .catch(err => console.error('Erro ao sincronizar o modelo Product:', err));

const app = express();
const PORT = 3000;

// Configurar middleware
app.use(cors({
    origin: 'http://192.168.100.44:8081', // Substitua pelo seu frontend, se necessário
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true,
}));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Configuração do multer para upload de fotos
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    },
});
const upload = multer({ storage });

// Rotas da API

// 1. Listar todos os produtos
app.get('/products', async (req, res) => {
    try {
        const products = await Product.findAll();
        res.json(products);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao listar produtos.' });
    }
});

// 2. Obter um produto pelo ID
app.get('/products/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const product = await Product.findByPk(id);

        if (!product) {
            return res.status(404).json({ error: 'Produto não encontrado.' });
        }

        res.json(product);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao buscar produto.' });
    }
});

// 3. Criar um novo produto
app.post('/products', upload.single('photo'), async (req, res) => {
    try {
        const { name, description, quantity } = req.body;
        const photo = req.file ? req.file.path : null;

        // Validar campos obrigatórios
        if (!name || !quantity) {
            return res.status(400).json({ error: 'Nome e quantidade são obrigatórios.' });
        }

        // Criar o novo produto
        const newProduct = await Product.create({
            name,
            description,
            quantity,
            photo,
        });

        res.status(201).json(newProduct);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao criar produto.' });
    }
});

// 4. Atualizar um produto
app.put('/products/:id', upload.single('photo'), async (req, res) => {
    try {
        const { id } = req.params;
        const { name, description, quantity } = req.body;
        const photo = req.file ? req.file.path : null;

        // Encontrar o produto
        const product = await Product.findByPk(id);

        if (!product) {
            return res.status(404).json({ error: 'Produto não encontrado.' });
        }

        // Atualizar os dados do produto
        product.name = name || product.name;
        product.description = description || product.description;
        product.quantity = quantity || product.quantity;
        if (photo) product.photo = photo;

        await product.save();

        res.json({ message: 'Produto atualizado com sucesso.', product });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao atualizar produto.' });
    }
});

// 5. Deletar um produto
app.delete('/products/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const product = await Product.findByPk(id);

        if (!product) {
            return res.status(404).json({ error: 'Produto não encontrado.' });
        }

        await product.destroy();

        res.json({ message: 'Produto deletado com sucesso.' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro ao deletar produto.' });
    }
});

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
